import React, { useEffect, useState } from 'react';
import ClockDisplay from './components/ClockDisplay';
import SetAlarmForm from './components/SetAlarmForm';
import AlarmList from './components/AlarmList';
import { getAlarms, createAlarm, deleteAlarm } from './api/alarmService';

function App() {
  const [alarms, setAlarms] = useState([]);

  useEffect(() => {
    loadAlarms();
  }, []);

  const loadAlarms = async () => {
    const data = await getAlarms();
    setAlarms(data);
  };

  const handleAddAlarm = async (alarm) => {
    await createAlarm(alarm);
    loadAlarms();
  };

  const handleDeleteAlarm = async (id) => {
    await deleteAlarm(id);
    loadAlarms();
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center">
      <h1 className="section-header">⏰ Digital Clock with Alarm</h1>
      <ClockDisplay alarms={alarms} />
      <SetAlarmForm onAddAlarm={handleAddAlarm} />
      <AlarmList alarms={alarms} onDeleteAlarm={handleDeleteAlarm} />
      <div className="footer-note">Made with ❤️ using React, Tailwind & Node.js</div>
    </div>
  );
}

export default App;
