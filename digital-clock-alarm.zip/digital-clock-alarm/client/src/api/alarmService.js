const API_URL = 'http://localhost:5000/api/alarms';

export const getAlarms = async () => {
  const res = await fetch(API_URL);
  return await res.json();
};

export const createAlarm = async (alarm) => {
  await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(alarm)
  });
};

export const deleteAlarm = async (id) => {
  await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
};
