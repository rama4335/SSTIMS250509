import React, { useEffect, useState } from 'react';

const ClockDisplay = ({ alarms }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const formatted = currentTime.toTimeString().slice(0, 5);
    const triggeredAlarm = alarms.find(alarm => alarm.time === formatted);
    if (triggeredAlarm) {
      alert(`⏰ Alarm: ${triggeredAlarm.label}`);
      const audio = new Audio('/alarm.mp3');
      audio.play();
    }
  }, [currentTime, alarms]);

  return (
    <div className="text-center text-3xl mb-6">
      {currentTime.toLocaleTimeString()}
    </div>
  );
};

export default ClockDisplay;
