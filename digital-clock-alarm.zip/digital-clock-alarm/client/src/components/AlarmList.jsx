import React from 'react';

const AlarmList = ({ alarms, onDeleteAlarm }) => (
  <div className="max-w-md mx-auto glass-card mt-6">
    <h2 className="glass-title">Your Alarms</h2>
    <ul>
      {alarms.map(alarm => (
        <li key={alarm._id} className="glass-alarm-item">
          <span>{alarm.time} - {alarm.label}</span>
          <button onClick={() => onDeleteAlarm(alarm._id)} className="text-red-400 hover:underline">Delete</button>
        </li>
      ))}
    </ul>
  </div>
);

export default AlarmList;
