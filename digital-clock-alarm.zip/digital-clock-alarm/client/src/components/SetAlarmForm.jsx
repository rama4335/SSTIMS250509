import React, { useState } from 'react';

const SetAlarmForm = ({ onAddAlarm }) => {
  const [time, setTime] = useState('');
  const [label, setLabel] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (time && label) {
      onAddAlarm({ time, label });
      setTime('');
      setLabel('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-4 mb-4 justify-center">
      <input type="time" value={time} onChange={e => setTime(e.target.value)} required className="glass-input w-[100px]" />
      <input type="text" value={label} onChange={e => setLabel(e.target.value)} placeholder="Label" className="glass-input w-[150px]" />
      <button type="submit" className="glass-button">Set Alarm</button>
    </form>
  );
};

export default SetAlarmForm;
