import express from 'express';
import { getAlarms, addAlarm, deleteAlarm } from '../controllers/alarmController.js';

const router = express.Router();

router.get('/', getAlarms);
router.post('/', addAlarm);
router.delete('/:id', deleteAlarm);

export default router;
