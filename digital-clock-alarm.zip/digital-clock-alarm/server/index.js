import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import alarmRoutes from './routes/alarmRoutes.js';

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/alarms')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

app.use('/api/alarms', alarmRoutes);

app.listen(5000, () => console.log('Server running on http://localhost:5000'));
