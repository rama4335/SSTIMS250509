import Alarm from '../models/Alarm.js';

export const getAlarms = async (req, res) => {
  const alarms = await Alarm.find();
  res.json(alarms);
};

export const addAlarm = async (req, res) => {
  const alarm = new Alarm(req.body);
  await alarm.save();
  res.status(201).json(alarm);
};

export const deleteAlarm = async (req, res) => {
  await Alarm.findByIdAndDelete(req.params.id);
  res.status(204).end();
};
