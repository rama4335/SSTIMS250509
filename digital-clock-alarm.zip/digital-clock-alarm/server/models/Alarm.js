import mongoose from 'mongoose';

const alarmSchema = new mongoose.Schema({
  time: String,
  label: String
}, { timestamps: true });

export default mongoose.model('Alarm', alarmSchema);
