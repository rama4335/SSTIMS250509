import tkinter as tk
from tkinter import messagebox
from datetime import datetime
import time
import threading

alarms = []

def set_alarm():
    time_input = entry_time.get()
    label = entry_label.get()
    if time_input and label:
        alarms.append((time_input, label))
        listbox.insert(tk.END, f"{time_input} - {label}")
        entry_time.delete(0, tk.END)
        entry_label.delete(0, tk.END)

def delete_alarm():
    selected = listbox.curselection()
    if selected:
        index = selected[0]
        listbox.delete(index)
        alarms.pop(index)

def check_alarm():
    while True:
        now = datetime.now().strftime("%H:%M")
        for time_set, label in alarms:
            if now == time_set:
                messagebox.showinfo("Alarm", f"⏰ Time for: {label}")
                time.sleep(60)
        time.sleep(1)

app = tk.Tk()
app.title("Digital Clock with Alarm")

tk.Label(app, text="Current Time:", font=("Arial", 18)).pack()
label_time = tk.Label(app, text="", font=("Arial", 24))
label_time.pack()

def update_time():
    label_time.config(text=datetime.now().strftime("%H:%M:%S"))
    app.after(1000, update_time)

update_time()

frame = tk.Frame(app)
frame.pack(pady=10)

entry_time = tk.Entry(frame, width=10)
entry_time.insert(0, "HH:MM")
entry_time.pack(side=tk.LEFT, padx=5)

entry_label = tk.Entry(frame, width=20)
entry_label.insert(0, "Label")
entry_label.pack(side=tk.LEFT, padx=5)

tk.Button(frame, text="Set Alarm", command=set_alarm).pack(side=tk.LEFT, padx=5)
tk.Button(frame, text="Delete Selected", command=delete_alarm).pack(side=tk.LEFT)

listbox = tk.Listbox(app, width=40)
listbox.pack(pady=10)

threading.Thread(target=check_alarm, daemon=True).start()
app.mainloop()
